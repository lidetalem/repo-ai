import React, { useEffect, useState } from 'react'
import { Plus, Pencil, Trash2, Eye } from 'lucide-react'
import toast from 'react-hot-toast'
import DataTable from '../../components/DataTable'
import Modal from '../../components/Modal'
import RegistrationForm from '../../components/RegistrationForm'
import { staffAPI } from '../../services/api'
import { useLang } from '../../context/LanguageContext'
import { usePrivilege } from '../../hooks/usePrivilege'
import AccessDenied from '../../components/AccessDenied'

export default function StaffPage() {
  const { t } = useLang()
  const { hasPrivilege } = usePrivilege()

  // ALL hooks must come before any conditional return
  const [data, setData]         = useState([])
  const [loading, setLoading]   = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [saving, setSaving]     = useState(false)
  const [selected, setSelected] = useState(null)
  const [viewItem, setViewItem] = useState(null)

  const canAccess = hasPrivilege('manage_staff')

  const load = () => {
    if (!canAccess) return
    setLoading(true)
    staffAPI.list()
      .then((r) => setData(r.data.results || r.data))
      .catch(() => toast.error('Failed to load staff'))
      .finally(() => setLoading(false))
  }

  useEffect(() => { load() }, [canAccess]) // eslint-disable-line react-hooks/exhaustive-deps

  // NOW it is safe to conditionally render
  if (!canAccess) {
    return <AccessDenied privilege="manage_staff" />
  }

  const handleSave = async (form) => {
    setSaving(true)
    try {
      if (selected) {
        const res = await staffAPI.update(selected.id, form)
        const updated = res.data || res
        if (JSON.stringify(updated) === JSON.stringify(selected)) {
          toast('No Changes Detected')
        } else {
          toast.success('Saved Successfully')
        }
      } else {
        await staffAPI.create({ ...form, registered_by: 'admin' })
        toast.success('Saved Successfully')
      }
      setSelected(null)
      setShowForm(false)
      load()
    } catch (err) {
      const msg = err.response?.data?.detail || Object.values(err.response?.data || {}).flat().join('\n') || 'Save failed'
      toast.error(msg)
    } finally {
      setSaving(false)
    }
  }

  const handleDelete = async (id) => {
    if (!window.confirm(t('confirmDelete'))) return
    try {
      await staffAPI.delete(id)
      toast.success('Deleted successfully')
      load()
    } catch {
      toast.error('Delete failed')
    }
  }

  const openEditor = (row) => { setSelected(row); setShowForm(true) }
  const openNew    = () => { setSelected(null); setShowForm(true) }
  const closeForm  = () => { setSelected(null); setShowForm(false) }

  const columns = [
    {
      key: 'profile_image',
      label: '',
      render: (v, row) => (
        <div className="w-9 h-9 rounded-xl overflow-hidden flex-shrink-0"
             style={{ background: 'var(--color-card-hover)' }}>
          {row.profile_image
            ? <img src={row.profile_image} alt="" className="w-full h-full object-cover" />
            : <div className="w-full h-full flex items-center justify-center text-sm font-bold"
                   style={{ color: 'var(--color-ameco-red)' }}>
                {row.first_name?.[0]?.toUpperCase()}
              </div>
          }
        </div>
      ),
    },
    {
      key: 'first_name',
      label: 'Name',
      render: (_, row) => (
        <div>
          <p className="font-semibold text-sm">{row.first_name} {row.middle_name} {row.last_name}</p>
          <p className="text-xs" style={{ color: 'var(--color-text-muted)' }}>{row.digital_id}</p>
        </div>
      ),
    },
    { key: 'position',   label: t('position') },
    { key: 'department', label: t('department') },
    { key: 'phone_number', label: t('phone') },
    {
      key: 'registered_at',
      label: 'Registered',
      render: (v) => v ? new Date(v).toLocaleDateString() : '—',
    },
  ]

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-bold" style={{ color: 'var(--color-text-main)' }}>
          {t('staff')} <span className="text-sm font-normal ml-1" style={{ color: 'var(--color-text-muted)' }}>
            ({data.length})
          </span>
        </h3>
        <button
          onClick={openNew}
          className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold text-white"
          style={{ background: 'linear-gradient(135deg,#cc0000,#aa0000)' }}>
          <Plus size={15} /> {t('addNew')}
        </button>
      </div>

      <DataTable
        columns={columns}
        data={data}
        loading={loading}
        searchKeys={['first_name', 'last_name', 'position', 'department', 'digital_id']}
        actions={(row) => (
          <>
            <button onClick={() => openEditor(row)} className="p-1.5 rounded-lg transition-all" style={{ color: '#f59e0b' }} title="Edit">
              <Pencil size={14} />
            </button>
            <button onClick={() => setViewItem(row)} className="p-1.5 rounded-lg transition-all" style={{ color: '#3b82f6' }} title="View">
              <Eye size={14} />
            </button>
            <button onClick={() => handleDelete(row.id)} className="p-1.5 rounded-lg transition-all" style={{ color: '#ef4444' }} title="Delete">
              <Trash2 size={14} />
            </button>
          </>
        )}
      />

      <Modal open={showForm} onClose={closeForm} title={selected ? 'Edit Staff' : t('registerStaff')} width="max-w-3xl">
        <RegistrationForm
          key={selected?.id ?? 'new-staff'}
          type="staff"
          initialData={selected}
          editing={!!selected}
          onSubmit={handleSave}
          onCancel={closeForm}
          loading={saving}
        />
      </Modal>

      <Modal open={!!viewItem} onClose={() => setViewItem(null)} title="Staff Details">
        {viewItem && (
          <div className="space-y-3 text-sm">
            {[
              ['Name', `${viewItem.first_name} ${viewItem.middle_name} ${viewItem.last_name}`],
              ['Digital ID', viewItem.digital_id],
              ['Position', viewItem.position],
              ['Department', viewItem.department],
              ['Phone', viewItem.phone_number],
              ['Email', viewItem.email],
              ['Gender', viewItem.gender],
              ['Description', viewItem.description],
              ['Registered At', viewItem.registered_at ? new Date(viewItem.registered_at).toLocaleString() : '—'],
            ].map(([label, value]) => (
              <div key={label} className="flex gap-3">
                <span className="w-32 flex-shrink-0 font-semibold" style={{ color: 'var(--color-text-muted)' }}>{label}</span>
                <span style={{ color: 'var(--color-text-main)' }}>{value || '—'}</span>
              </div>
            ))}
          </div>
        )}
      </Modal>
    </div>
  )
}